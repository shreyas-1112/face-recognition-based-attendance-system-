from flask import Flask, render_template, request, jsonify, Response, send_file
import cv2
import os
import pickle
import pandas as pd
import json
from datetime import datetime, timedelta
import numpy as np
from pathlib import Path
import csv
from utils import ensure_dir, ensure_haarcascade

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'dataset'
app.config['DATABASE_FILE'] = 'students_database.json'

# Global variables
camera = None
recognizer = None
label_names = {}
face_cascade = None

def initialize_models():
    """Initialize face recognizer and cascade classifier"""
    global recognizer, label_names, face_cascade
    
    models_dir = "models"
    ensure_dir(models_dir)
    cascade_path = os.path.join(models_dir, "haarcascade_frontalface_default.xml")
    ensure_haarcascade(cascade_path)
    
    face_cascade = cv2.CascadeClassifier(cascade_path)
    
    model_path = 'models/face_recognizer.yml'
    labels_path = 'models/labels.pickle'
    
    if os.path.exists(model_path) and os.path.exists(labels_path):
        try:
            recognizer = cv2.face.LBPHFaceRecognizer_create()
            recognizer.read(model_path)
            with open(labels_path, 'rb') as f:
                label_names = pickle.load(f)
        except Exception as e:
            print(f"Error loading model: {e}")

def load_students_database():
    """Load students database from JSON file"""
    if os.path.exists(app.config['DATABASE_FILE']):
        with open(app.config['DATABASE_FILE'], 'r') as f:
            return json.load(f)
    return {}

def save_students_database(database):
    """Save students database to JSON file"""
    with open(app.config['DATABASE_FILE'], 'w') as f:
        json.dump(database, f, indent=4)

def load_attendance_records(days=30):
    """Load attendance records from CSV"""
    attendance_file = 'attendance.csv'
    if not os.path.exists(attendance_file):
        return pd.DataFrame(columns=['Name', 'Date', 'Time'])
    
    df = pd.read_csv(attendance_file)
    if not df.empty:
        df['Date'] = pd.to_datetime(df['Date'])
        cutoff_date = datetime.now() - timedelta(days=days)
        df = df[df['Date'] >= cutoff_date]
    return df

@app.route('/')
def index():
    """Dashboard page"""
    return render_template('index.html')

@app.route('/api/dashboard-stats')
def dashboard_stats():
    """Get dashboard statistics"""
    students_db = load_students_database()
    attendance_df = load_attendance_records(days=30)
    
    total_students = len(students_db)
    
    # Today's attendance
    today = datetime.now().date()
    if not attendance_df.empty:
        today_attendance = attendance_df[attendance_df['Date'].dt.date == today]
        present_today = len(today_attendance['Name'].unique())
    else:
        present_today = 0
    
    # Weekly attendance
    week_ago = datetime.now() - timedelta(days=7)
    if not attendance_df.empty:
        weekly_attendance = attendance_df[attendance_df['Date'] >= week_ago]
        avg_weekly_attendance = len(weekly_attendance) / 7
    else:
        avg_weekly_attendance = 0
    
    # Branch-wise distribution
    branch_stats = {}
    for student_id, student_info in students_db.items():
        branch = student_info.get('branch', 'Unknown')
        branch_stats[branch] = branch_stats.get(branch, 0) + 1
    
    return jsonify({
        'total_students': total_students,
        'present_today': present_today,
        'absent_today': total_students - present_today,
        'avg_weekly_attendance': round(avg_weekly_attendance, 1),
        'branch_stats': branch_stats
    })

@app.route('/api/recent-attendance')
def recent_attendance():
    """Get recent attendance records"""
    attendance_df = load_attendance_records(days=7)
    if attendance_df.empty:
        return jsonify([])
    
    recent = attendance_df.tail(50).to_dict('records')
    for record in recent:
        record['Date'] = record['Date'].strftime('%Y-%m-%d') if isinstance(record['Date'], pd.Timestamp) else record['Date']
    
    return jsonify(recent)

@app.route('/students')
def students():
    """Students management page"""
    return render_template('students.html')

@app.route('/api/students')
def get_students():
    """Get all students"""
    students_db = load_students_database()
    students_list = []
    
    for student_id, student_info in students_db.items():
        student_info['id'] = student_id
        students_list.append(student_info)
    
    return jsonify(students_list)

@app.route('/api/students/<student_id>')
def get_student(student_id):
    """Get single student details"""
    students_db = load_students_database()
    if student_id in students_db:
        student = students_db[student_id]
        student['id'] = student_id
        return jsonify(student)
    return jsonify({'error': 'Student not found'}), 404

@app.route('/api/students', methods=['POST'])
def add_student():
    """Add new student"""
    data = request.json
    students_db = load_students_database()
    
    student_id = data.get('student_id')
    if student_id in students_db:
        return jsonify({'error': 'Student ID already exists'}), 400
    
    students_db[student_id] = {
        'name': data.get('name'),
        'email': data.get('email'),
        'phone': data.get('phone'),
        'branch': data.get('branch'),
        'year': data.get('year'),
        'section': data.get('section'),
        'enrollment_date': datetime.now().strftime('%Y-%m-%d'),
        'images_captured': 0
    }
    
    save_students_database(students_db)
    return jsonify({'message': 'Student added successfully', 'student_id': student_id})

@app.route('/api/students/<student_id>', methods=['PUT'])
def update_student(student_id):
    """Update student information"""
    data = request.json
    students_db = load_students_database()
    
    if student_id not in students_db:
        return jsonify({'error': 'Student not found'}), 404
    
    students_db[student_id].update({
        'name': data.get('name'),
        'email': data.get('email'),
        'phone': data.get('phone'),
        'branch': data.get('branch'),
        'year': data.get('year'),
        'section': data.get('section')
    })
    
    save_students_database(students_db)
    return jsonify({'message': 'Student updated successfully'})

@app.route('/api/students/<student_id>', methods=['DELETE'])
def delete_student(student_id):
    """Delete student"""
    students_db = load_students_database()
    
    if student_id not in students_db:
        return jsonify({'error': 'Student not found'}), 404
    
    # Get student name for dataset deletion
    student_name = students_db[student_id]['name']
    
    # Remove from database
    del students_db[student_id]
    save_students_database(students_db)
    
    # Optionally remove dataset folder
    dataset_path = os.path.join(app.config['UPLOAD_FOLDER'], student_name)
    if os.path.exists(dataset_path):
        import shutil
        shutil.rmtree(dataset_path)
    
    return jsonify({'message': 'Student deleted successfully'})

@app.route('/capture')
def capture():
    """Face capture page"""
    return render_template('capture.html')

@app.route('/api/capture-start', methods=['POST'])
def start_capture():
    """Start capturing images for a student"""
    data = request.json
    student_name = data.get('name')
    count = data.get('count', 60)
    
    # Update database with capture info
    students_db = load_students_database()
    for student_id, student_info in students_db.items():
        if student_info['name'] == student_name:
            students_db[student_id]['images_captured'] = count
            save_students_database(students_db)
            break
    
    return jsonify({'message': 'Capture started', 'name': student_name, 'count': count})

@app.route('/recognition')
def recognition():
    """Live recognition page"""
    return render_template('recognition.html')

def generate_frames():
    """Generate video frames with face recognition"""
    global recognizer, label_names, face_cascade
    
    if recognizer is None:
        initialize_models()
    
    camera = cv2.VideoCapture(0)
    attendance_log = {}
    
    while True:
        success, frame = camera.read()
        if not success:
            break
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        
        for (x, y, w, h) in faces:
            face_roi = gray[y:y+h, x:x+w]
            
            if recognizer is not None and label_names:
                label, confidence = recognizer.predict(face_roi)
                
                if confidence < 70:  # Recognition threshold
                    name = label_names.get(label, "Unknown")
                    color = (0, 255, 0)
                    
                    # Log attendance (once per session per person)
                    current_time = datetime.now()
                    if name not in attendance_log:
                        attendance_log[name] = current_time
                        log_attendance(name, current_time)
                else:
                    name = "Unknown"
                    color = (0, 0, 255)
                
                cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                cv2.putText(frame, f"{name} ({int(confidence)})", (x, y-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
            else:
                cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
                cv2.putText(frame, "No Model", (x, y-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
        
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    
    camera.release()

def log_attendance(name, timestamp):
    """Log attendance to CSV file"""
    attendance_file = 'attendance.csv'
    file_exists = os.path.exists(attendance_file)
    
    with open(attendance_file, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['Name', 'Date', 'Time'])
        writer.writerow([name, timestamp.strftime('%Y-%m-%d'), timestamp.strftime('%H:%M:%S')])

@app.route('/video_feed')
def video_feed():
    """Video streaming route"""
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/attendance')
def attendance():
    """Attendance records page"""
    return render_template('attendance.html')

@app.route('/api/attendance')
def get_attendance():
    """Get attendance records with filters"""
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    student_name = request.args.get('student_name')
    
    attendance_df = load_attendance_records(days=365)
    
    if not attendance_df.empty:
        if start_date:
            attendance_df = attendance_df[attendance_df['Date'] >= pd.to_datetime(start_date)]
        if end_date:
            attendance_df = attendance_df[attendance_df['Date'] <= pd.to_datetime(end_date)]
        if student_name:
            attendance_df = attendance_df[attendance_df['Name'].str.contains(student_name, case=False)]
        
        records = attendance_df.to_dict('records')
        for record in records:
            record['Date'] = record['Date'].strftime('%Y-%m-%d') if isinstance(record['Date'], pd.Timestamp) else record['Date']
        
        return jsonify(records)
    
    return jsonify([])

@app.route('/api/train-model', methods=['POST'])
def train_model():
    """Trigger model training"""
    try:
        from train import train
        train()
        initialize_models()
        return jsonify({'message': 'Model trained successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/reports')
def reports():
    """Reports page"""
    return render_template('reports.html')

@app.route('/api/export-attendance')
def export_attendance():
    """Export attendance records to CSV"""
    attendance_file = 'attendance.csv'
    if os.path.exists(attendance_file):
        return send_file(attendance_file, as_attachment=True, download_name=f'attendance_{datetime.now().strftime("%Y%m%d")}.csv')
    return jsonify({'error': 'No attendance records found'}), 404

if __name__ == '__main__':
    ensure_dir('dataset')
    ensure_dir('models')
    initialize_models()
    app.run(debug=True, host='0.0.0.0', port=5000)
