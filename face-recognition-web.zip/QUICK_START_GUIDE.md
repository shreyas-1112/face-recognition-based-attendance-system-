# 🚀 Quick Start Guide

## Face Recognition Attendance System - Web Interface

Get your attendance system up and running in 5 minutes!

---

## 📋 Prerequisites

- ✅ Python 3.8 or higher
- ✅ Webcam/Camera
- ✅ Windows/Linux/Mac OS

---

## ⚡ Quick Start (3 Steps)

### Step 1: Install Dependencies

**Windows:**
```bash
pip install -r requirements_web.txt
```

**Linux/Mac:**
```bash
pip3 install -r requirements_web.txt
```

### Step 2: Start the Server

**Windows:**
```bash
# Double-click start_web_server.bat
# OR run in command prompt:
python app.py
```

**Linux/Mac:**
```bash
# Make script executable:
chmod +x start_web_server.sh

# Run the script:
./start_web_server.sh

# OR directly:
python3 app.py
```

### Step 3: Open Your Browser

Navigate to: **http://localhost:5000**

🎉 **That's it! You're ready to go!**

---

## 📖 First-Time Workflow

### 1️⃣ Add Students (2 minutes)

1. Click **Students** in sidebar
2. Click **"Add New Student"** button
3. Fill in:
   - Student ID
   - Name
   - Email (optional)
   - Phone (optional)
   - Branch (e.g., Computer Science)
   - Year (1-4)
   - Section (optional)
4. Click **"Add Student"**

### 2️⃣ Capture Face Images (3-5 minutes per student)

1. Click **Capture Images** in sidebar
2. Select student from dropdown
3. Set image count: **60** (recommended)
4. Click **"Start Capture"**
5. **Important:** Copy and run the command shown:
   ```bash
   python capture.py --name "StudentName" --count 60
   ```
6. Follow these tips during capture:
   - ✅ Good lighting
   - ✅ Look at camera
   - ✅ Slowly turn head for different angles
   - ✅ Keep face in green box
   - ⌨️ Press 'q' to quit early

### 3️⃣ Train the Model (1 minute)

1. Click **"Train Model"** button in sidebar
2. Wait for training to complete
3. You'll see a success message

### 4️⃣ Start Recognition (Instant)

1. Click **Live Recognition** in sidebar
2. Camera feed starts automatically
3. ✅ Recognized faces = Green box + Name
4. ❌ Unknown faces = Red box
5. Attendance logs automatically!

### 5️⃣ View Reports

1. **Dashboard**: Overview and statistics
2. **Attendance Records**: Filter and export data
3. **Reports**: Analytics and insights

---

## 🎯 Pro Tips

### For Best Recognition Results:

1. **Capture Quality**
   - 60-100 images per person
   - Good, even lighting
   - Multiple angles
   - Clear, focused images

2. **Training**
   - Train model after adding multiple students
   - Retrain if recognition accuracy drops
   - More images = better accuracy

3. **Recognition**
   - Ensure good lighting conditions
   - Face the camera directly
   - Minimum movement for best results

### Performance Optimization:

- **Fast Computer**: Better real-time performance
- **Good Camera**: Higher quality = better recognition
- **Regular Training**: Update model as you add students

---

## 🔧 Common Issues & Solutions

### ❌ Camera not working?
**Solution:**
- Check camera permissions
- Close other apps using camera
- Try different camera: `cv2.VideoCapture(1)` in code

### ❌ Faces not recognized?
**Solution:**
- Capture more images (80-100)
- Improve lighting during capture
- Click "Train Model" button
- Check confidence threshold in settings

### ❌ Port 5000 already in use?
**Solution:**
- Change port in `app.py`: 
  ```python
  app.run(port=5001)
  ```

### ❌ Module not found error?
**Solution:**
```bash
pip install opencv-contrib-python flask pandas numpy
```

---

## 📁 File Structure Overview

```
project/
├── app.py                    # 🌐 Main Flask web application
├── capture.py                # 📸 Image capture script
├── train.py                  # 🧠 Model training script
├── utils.py                  # 🛠️ Helper functions
├── requirements_web.txt      # 📦 Dependencies
├── start_web_server.sh       # 🚀 Linux/Mac startup script
├── start_web_server.bat      # 🚀 Windows startup script
│
├── templates/                # 🎨 HTML pages
│   ├── index.html           # Dashboard
│   ├── students.html        # Student management
│   ├── capture.html         # Image capture
│   ├── recognition.html     # Live recognition
│   ├── attendance.html      # Attendance records
│   └── reports.html         # Reports & analytics
│
├── static/css/              # 💅 Styles
├── dataset/                 # 📷 Face images (auto-created)
├── models/                  # 🤖 Trained models (auto-created)
├── attendance.csv           # 📊 Attendance log (auto-created)
└── students_database.json   # 💾 Student info (auto-created)
```

---

## 🎨 Interface Overview

### 🏠 Dashboard
- Total students count
- Today's attendance
- Weekly statistics
- Visual charts
- Recent activity

### 👥 Students
- Add/Edit/Delete students
- View all student details
- Track captured images
- Branch-wise organization

### 📸 Capture
- Guided image capture
- Best practice tips
- Progress tracking
- Quality guidelines

### 🎥 Live Recognition
- Real-time video feed
- Face detection boxes
- Confidence scores
- Auto-attendance logging
- Session statistics

### 📋 Attendance
- Complete records
- Date filtering
- Name search
- Export to CSV
- Visual trends

### 📈 Reports
- Daily/Weekly/Monthly reports
- Student-specific reports
- Attendance statistics
- Low attendance alerts
- Custom date ranges

---

## 🔒 Security Note

⚠️ **For Production Use:**
1. Change the secret key in `app.py`
2. Disable debug mode
3. Add user authentication
4. Use HTTPS
5. Implement access controls

---

## 📞 Need Help?

1. Check `WEB_INTERFACE_README.md` for detailed documentation
2. Review troubleshooting section
3. Ensure all files are in correct locations
4. Verify Python version: `python --version`

---

## 🎉 You're All Set!

Your Face Recognition Attendance System is ready to use!

**Quick Access:**
- 🌐 Web Interface: http://localhost:5000
- 📚 Full Documentation: WEB_INTERFACE_README.md
- 🐛 Troubleshooting: See README

**Enjoy your automated attendance system!** 🚀

---

**Made with ❤️ for educational purposes**
